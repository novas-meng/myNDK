package com.ffaudio;

import android.app.Activity;
import android.os.Bundle;

public class ffaudioActivity extends Activity {
	public static final String[] LIBS = new String[] {
		"ffplay", // used for access to android native AudioTrack class 
		"ffaudio"	// ffmpeg libs compiled to jni lib
	};

	private static boolean sLoaded = false;

    private static boolean loadLibs() {
    	if(sLoaded)
    		return true;

    	boolean err = false;
    	for(int i=0;i<LIBS.length;i++) {
    		try {
    			System.loadLibrary(LIBS[i]);
    		} catch(UnsatisfiedLinkError e) {
    			// fatal error, we can't load some our libs
    			err = true;
    		}
		}

    	if(!err)
    		sLoaded = true;

    	return sLoaded;
    }
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        loadLibs();
        
        nativePlay("/sdcard/test.wav");
    }
   
    private native void nativePlay(String fname);
}