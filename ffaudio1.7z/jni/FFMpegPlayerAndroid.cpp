
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include "drivers_map.h"
#include <android/log.h>

int jniRegisterNativeMethods(JNIEnv* env, const char* className, const JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;

    clazz = env->FindClass(className);
    if (clazz == NULL)
        return -1;

    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
        return -1;

    return 0;
}

static void FFMpegPlayerAndroid_play(JNIEnv *env, jobject obj, jstring fname) 
{
	jboolean isCopy;
    const char * szfname = env->GetStringUTFChars(fname, &isCopy);    
	FILE  *fp = fopen(szfname, "rb");	
    env->ReleaseStringUTFChars(fname, szfname);
    
    int i;
    int *pfmt;
    char buf[2048];
    
    fread(buf, 1, 80, fp);
    
    for(i=0; i<76; i+=4)
    {
    	pfmt = (int*)(buf+i);
    	if(*pfmt == 0x20746D66) // 'fmt ' ��Ƶ��ʽ��ʶ��
    		break;		
	}
	
	if(i>70)
		return; // ��wav�ļ�
		
	char pcmtag = buf[i+8];
	if(pcmtag!=1)
		return ; // ��pcm����

	int channels =  buf[i+10];		
	int sample_rate = ((int)buf[i+13])*256+buf[i+12];
	int bits =buf[i+22];	
    
	if(AudioDriver_register() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) 
		return ;
	
	if(AudioDriver_set(MUSIC, sample_rate, (bits == 16) ? PCM_16_BIT : PCM_8_BIT, (channels == 2) ? CHANNEL_OUT_STEREO : CHANNEL_OUT_MONO) != ANDROID_AUDIOTRACK_RESULT_SUCCESS) 
		return ;
	
	if(AudioDriver_start() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) 
		return ;

	fseek(fp, 0, SEEK_SET); 
		
	unsigned int iread=2048;
	
	for(;;)
	{		
		iread = fread(buf, 1, 2048, fp);
		if(iread!=2048)
			break;
		
		if(AudioDriver_write(buf, iread) <= 0) 
			break ;
		
		AudioDriver_flush();
	}
	
	if(AudioDriver_unregister() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) 
	{
//		jniThrowException(env, "java/io/IOException", "Couldn't unregister audio track");
	}
	
	fclose(fp);
}

/*
* JNI registration.
*/
static JNINativeMethod methods[] = {
	{ "nativePlay", "(Ljava/lang/String;)V", (void*) FFMpegPlayerAndroid_play },
};

int register_android_media_FFMpegPlayerAndroid(JNIEnv *env) 
{
	return jniRegisterNativeMethods(env, "com/ffaudio/ffaudioActivity", methods, sizeof(methods) / sizeof(methods[0]));
}
