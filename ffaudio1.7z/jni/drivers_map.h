#ifndef _DRIVERS_MAP_H_
#define _DRIVERS_MAP_H_

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

// methods for access to audio on OS
typedef int (*audioDriver_register_t) ();
typedef int (*audioDriver_set_t) (int,uint32_t,int,int);
typedef int (*audioDriver_start_t) (void);
typedef int (*audioDriver_flush_t) (void);
typedef int (*audioDriver_stop_t) (void);
typedef int (*audioDriver_reload_t) (void);
typedef int (*audioDriver_unregister_t) (void);
typedef int (*audioDriver_write_t) (void *, int);

#include "audiotrack.h"

audioDriver_register_t AudioDriver_register = AndroidAudioTrack_register;
audioDriver_set_t AudioDriver_set = AndroidAudioTrack_set;
audioDriver_start_t AudioDriver_start = AndroidAudioTrack_start;
audioDriver_flush_t AudioDriver_flush = AndroidAudioTrack_flush;
audioDriver_stop_t AudioDriver_stop = AndroidAudioTrack_stop;
audioDriver_reload_t AudioDriver_reload = AndroidAudioTrack_reload;
audioDriver_write_t AudioDriver_write = AndroidAudioTrack_write;
audioDriver_unregister_t AudioDriver_unregister = AndroidAudioTrack_unregister;

#ifdef __cplusplus
} // end of cpluplus
#endif

#endif
